<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Welcome To My Website</b>
    </div>
    <strong>b.ravindhar2006@gmail.com</strong>
</footer>