<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2018 Brought to You By <a href="https://code-projects.org/">Code-Projects</a></strong>
    </div>
</footer>